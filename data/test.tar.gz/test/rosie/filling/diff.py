import os
import subprocess
import shlex

for test_d in filter(lambda x: x.startswith('test-'), os.listdir('.')):
    for fill in os.listdir(test_d):
        if not fill.startswith('train-'):
            continue
        num = int(fill.split('-')[1])
        of = open(os.path.join(os.path.join(test_d, fill), 'diff2.filtered'),'w')
        cwd = os.getcwd()
        command = 'python '+ os.path.join(cwd, '../../../scripts/diff_info.py') + ' --chothia 1 ' + os.path.join(cwd, '../rosetta/vh.kabat') + ' ' + os.path.join(os.path.join(test_d, fill), 'vh-prediction.filtered.kabat')
        p = subprocess.Popen(shlex.split(command), universal_newlines=True, stdout=of)
        p.wait()
        of.close()