Данные использовались для написания статьи на ISMB (https://github.com/zmactep/igcat) 
Взяты из ./test/ из https://github.com/zmactep/ig-annotator
Удалены результаты тестов, оставлены только входные данные.
Данные будут использованы для тестов ig-snooper